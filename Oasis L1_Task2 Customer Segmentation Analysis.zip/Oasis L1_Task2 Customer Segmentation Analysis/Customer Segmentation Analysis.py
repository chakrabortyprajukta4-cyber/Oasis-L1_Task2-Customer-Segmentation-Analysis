# Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# ------------------------------------------
# Load Dataset
# ------------------------------------------

df = pd.read_csv("c:\\Users\\aishw\\Downloads\\SampleSuperstore.csv")

print("="*60)
print("First 5 Rows")
print(df.head())

print("\nDataset Shape")
print(df.shape)

print("\nColumns")
print(df.columns)

print("\nDataset Information")
print(df.info())

# ------------------------------------------
# Missing Values
# ------------------------------------------

print("\nMissing Values")
print(df.isnull().sum())

# Remove missing values
df.dropna(inplace=True)

# Remove duplicate rows
df.drop_duplicates(inplace=True)

print("\nDataset Shape After Cleaning")
print(df.shape)

# ------------------------------------------
# Descriptive Statistics
# ------------------------------------------

print("\nDescriptive Statistics")
print(df.describe())

print("\nAverage Sales:", round(df["Sales"].mean(),2))
print("Average Quantity:", round(df["Quantity"].mean(),2))
print("Average Profit:", round(df["Profit"].mean(),2))

# ------------------------------------------
# Feature Selection
# ------------------------------------------

features = df[["Sales","Quantity","Profit"]]

# ------------------------------------------
# Standardization
# ------------------------------------------

scaler = StandardScaler()

scaled_features = scaler.fit_transform(features)

# ------------------------------------------
# Elbow Method
# ------------------------------------------

wcss = []

for i in range(1,11):
    kmeans = KMeans(
        n_clusters=i,
        random_state=42,
        n_init=10
    )
    kmeans.fit(scaled_features)
    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8,5))
plt.plot(range(1,11),wcss,marker='o')
plt.title("Elbow Method")
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")
plt.grid(True)
plt.show()

# ------------------------------------------
# Apply KMeans
# ------------------------------------------

k = 4

kmeans = KMeans(
    n_clusters=k,
    random_state=42,
    n_init=10
)

df["Cluster"] = kmeans.fit_predict(scaled_features)

print("\nCluster Assigned Successfully!")

# ------------------------------------------
# Scatter Plot 1
# ------------------------------------------

plt.figure(figsize=(8,6))

sns.scatterplot(
    data=df,
    x="Sales",
    y="Profit",
    hue="Cluster",
    palette="Set1"
)

plt.title("Sales vs Profit")
plt.show()

# ------------------------------------------
# Scatter Plot 2
# ------------------------------------------

plt.figure(figsize=(8,6))

sns.scatterplot(
    data=df,
    x="Quantity",
    y="Sales",
    hue="Cluster",
    palette="Set2"
)

plt.title("Quantity vs Sales")
plt.show()

# ------------------------------------------
# Customers Per Cluster
# ------------------------------------------

plt.figure(figsize=(7,5))

sns.countplot(
    x="Cluster",
    data=df
)

plt.title("Number of Records in Each Cluster")
plt.xlabel("Cluster")
plt.ylabel("Count")

plt.show()

# ------------------------------------------
# Cluster Profile
# ------------------------------------------

cluster_profile = df.groupby("Cluster")[["Sales","Quantity","Profit"]].mean()

print("\nCluster Profile")
print(cluster_profile)

# ------------------------------------------
# Cluster Size
# ------------------------------------------

cluster_size = df["Cluster"].value_counts().sort_index()

print("\nCluster Size")
print(cluster_size)

# ------------------------------------------
# Marketing Insights
# ------------------------------------------

print("\n==============================")
print("Marketing Insights")
print("==============================")

for cluster in cluster_profile.index:

    sales = cluster_profile.loc[cluster,"Sales"]
    quantity = cluster_profile.loc[cluster,"Quantity"]
    profit = cluster_profile.loc[cluster,"Profit"]

    print(f"\nCluster {cluster}")

    print(f"Average Sales : {sales:.2f}")
    print(f"Average Quantity : {quantity:.2f}")
    print(f"Average Profit : {profit:.2f}")

    if sales > cluster_profile["Sales"].mean():

        print("Recommendation:")
        print("- Premium offers")
        print("- Loyalty rewards")
        print("- Exclusive discounts")

    elif profit < 0:

        print("Recommendation:")
        print("- Reduce discount")
        print("- Improve pricing")
        print("- Focus on profitable products")

    else:

        print("Recommendation:")
        print("- Cross-selling")
        print("- Bundle offers")
        print("- Seasonal promotions")

# ------------------------------------------
# Save Results
# ------------------------------------------

df.to_csv("c:\\Users\\aishw\\Downloads\\Customer_Segmentation_Result.csv",index=False)

print("\nResult Saved Successfully!")

print("\nFile Name:")
print("c:\\Users\\aishw\\Downloads\\Customer_Segmentation_Result.csv")

print("\nProject Completed Successfully!")